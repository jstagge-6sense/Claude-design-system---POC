// Reads the data the build script embedded in the HTML page.
export type TokenKind = 'color' | 'gradient' | 'dimension' | 'number' | 'shadow' | 'typography' | 'fontFamily' | 'fontWeight' | 'lineHeight' | 'string'
export interface TokenRec {
  name: string; layer: 'primitive' | 'semantic' | 'component' | 'theme'; kind: TokenKind; type?: string
  value: string; css: string | null; parts?: Record<string, string>; aliases: string[]; description?: string
  file: string; gap?: string; cssVar: string
}
export interface PreviewData {
  tokens: Record<string, TokenRec>
  gaps: Array<{ id: string; token: string; aliases: string[]; note: string }>
  state: { level?: string; gaps?: unknown[]; conflicts?: Array<{ id: string; title: string; detail: string; status?: string }>; deferred?: unknown[]; components?: Record<string, { status: string }> }
  builtAt: string
}
const el = typeof document !== 'undefined' ? document.getElementById('ds-data') : null
export const DATA: PreviewData = el ? JSON.parse(el.textContent || '{}') : { tokens: {}, gaps: [], state: {}, builtAt: '' }
export const TOKEN_LIST: TokenRec[] = Object.values(DATA.tokens)
